package kr.pe.cshop.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.pe.cshop.model.dao.MemoryCardRepository;

@Service
public class MemoryCardService {

    @Autowired
    MemoryCardRepository mcRepository;
}
