package kr.pe.cshop.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import kr.pe.cshop.model.dao.MemoryCardRepository;
import kr.pe.cshop.model.domain.MemoryCard;

public class MemoryCardServiceImpl {
    @Autowired
    MemoryCardRepository mcRepo;

    public List<MemoryCard> getMemoryCardList(MemoryCard mc){
        return (List<MemoryCard>) mcRepo.findAll();
    }
    
}
