package io.playdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FpBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
